class TreeNode {
    int data;
    TreeNode left, right;

    public TreeNode(int item) {
        data = item;
        left = right = null;
    }
}

public class TreeTypeChecker {

    TreeNode root;
    boolean isFullTree(TreeNode node) {
        if (node == null)
            return true;

        if ((node.left == null && node.right != null) || (node.left != null && node.right == null))
            return false;

        return isFullTree(node.left) && isFullTree(node.right);
    }

    boolean isCompleteTree(TreeNode node) {
        if (node == null)
            return true;

        java.util.Queue<TreeNode> queue = new java.util.LinkedList<>();
        queue.add(node);
        boolean flag = false;

        while (!queue.isEmpty()) {
            TreeNode current = queue.poll();

            if (current.left != null) {
                if (flag)
                    return false;
                queue.add(current.left);
            } else {
                flag = true;
            }

            if (current.right != null) {
                if (flag)
                    return false;
                queue.add(current.right);
            } else {
                flag = true;
            }
        }

        return true;
    }

    public void checkTreeType(TreeNode node) {
        boolean isFull = isFullTree(node);
        boolean isComplete = isCompleteTree(node);

        if (isFull && isComplete) {
            System.out.println("The tree is both a Full Tree and a Complete Tree.");
        } else if (isFull) {
            System.out.println("The tree is a Full Tree.");
        } else if (isComplete) {
            System.out.println("The tree is a Complete Tree.");
        } else {
            System.out.println("The tree is neither a Full Tree nor a Complete Tree.");
        }
    }

    public static void main(String[] args) {
        TreeTypeChecker tree = new TreeTypeChecker();

        tree.root = new TreeNode(1);
        tree.root.left = new TreeNode(2);
        tree.root.right = new TreeNode(3);
        tree.root.left.left = new TreeNode(4);
        tree.root.left.right = new TreeNode(5);
        tree.root.right.left = new TreeNode(6);

        tree.checkTreeType(tree.root);
    }
}
