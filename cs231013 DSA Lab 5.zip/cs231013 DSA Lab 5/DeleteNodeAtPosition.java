class Node {
    int data;
    Node prev;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    private Node head;
    private Node tail;

    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    public void append(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void deleteAtPosition(int position) {
        if (position < 0 || head == null) {
            System.out.println("Invalid position or list is empty.");
            return;
        }

        Node current = head;

        if (position == 0) {
            if (head == tail) { 
                head = tail = null;
            } else {
                head = head.next;
                head.prev = null;
            }
            return;
        }

        int index = 0;

        while (current != null && index < position) {
            current = current.next;
            index++;
        }

        if (current == null) { 
            System.out.println("Position out of bounds.");
            return;
        }
        if (current.next != null) {
            current.next.prev = current.prev;
        } else { 
            tail = current.prev;
        }

        if (current.prev != null) {
            current.prev.next = current.next;
        }
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteNodeAtPosition {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        list.append(10);
        list.append(20);
        list.append(30);
        list.append(40);
        list.append(50);

        System.out.println("Original list:");
        list.display();

        System.out.println("Deleting node at position 2:");
        list.deleteAtPosition(2);
        list.display();

        System.out.println("Deleting node at position 0:");
        list.deleteAtPosition(0);
        list.display();

        System.out.println("Deleting node at position 10:");
        list.deleteAtPosition(10);
        list.display();
    }
}
